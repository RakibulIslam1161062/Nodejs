const express = require('express');
const router = express.Router();
const Ninja = require('../models/ninja');
const mongoose = require('mongoose');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

router.get('/ninjas',  async function  (req, res) {


    MongoClient.connect(url,async function(err, db) {
  if (err) throw err;
  var dbo = db.db("ninjago");
  console.log("lolii");



  /*var data = dbo.collection('ninjas').find().limit(1).sort({$natural:-1});
  console.log(data.lat);
//  res.json(data);
  */
  /*  var result=  db.bios.findOne();
    console.log(result);
    res.send(result);
    db.close();
    */
  //dbo.collection("ninjas").find().limit(1).sort({$natural:-1})
/*await  dbo.collection("ninjas").find({}).toArray(function(err, result) {
    if (err) throw err;
    console.log(result[0]);
    res.send(result[0]);
    db.close();
  }); */
  dbo.collection("ninjas", function(err, collection) {
  collection
    .find()
    .sort({$natural: -1})
    .limit(1)
    .next()
    .then(
      function(doc) {
        console.log(doc);
        res.send(doc);
      },
      function(err) {
        console.log('Error:', err);
      }
    );
});



});

});

  //return (db.getCollection('ninjas').find().limit(1).sort({$natural:-1}));




  //res.send({type:'GET'});
//  Ninja.geoNear(
//    {
//      type:'Point',coordinates:[parseFloat(req.query.lng),parseFloat(req.query.lat)]
//    },
//    {maxDistance: 100000, spherical:true}
//  ).then(function(ninja){
  //  res.send(ninja);
//  });


    //var cursor=db.collection("ninjas").find().limit(1).sort({$natural:-1});
  //  res.send(cursor);
//Ninja.aggregate([{ $geoNear: { near: {type: 'Point', coordinates: [parseFloat(req.query.lng), parseFloat(req.query.lat)]}, spherical: true, maxDistance: 100000, distanceField: "dist.calculated" } }]).then(function(results){ res.send(results); });



router.post('/ninjas', function (req, res, next) {
  console.log(req.body);
  Ninja.create(req.body).then(function(ninja){
    res.send(ninja);
  }).catch(next);

});
router.put('/ninjas/:id',function (req, res, next) {
  res.send({type:'put'});
});

module.exports = router;
